import static org.junit.Assert.*;

import org.junit.Test;

public class login1Test {

	@Test
	public void test() {
	 login1 test = new login1();
	}

}
